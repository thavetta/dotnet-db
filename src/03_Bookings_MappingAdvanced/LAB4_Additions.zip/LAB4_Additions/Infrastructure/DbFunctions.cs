namespace Bookings.Infrastructure;

public static class DbFunctions
{
    // Body se v SQL nepoužije; je zde kvůli volání v LINQ
    public static int Nights(DateOnly from, DateOnly to) => (to.DayNumber - from.DayNumber);
}
