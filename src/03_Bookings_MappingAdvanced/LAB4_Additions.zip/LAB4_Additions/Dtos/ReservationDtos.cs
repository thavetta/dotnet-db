using Bookings.Models;

namespace Bookings.Dtos;

public record ReservationCreateDto(Guid GuestId, Guid RoomId, DateOnly From, DateOnly To, MoneyDto Total);
public record ReservationUpdateDto(DateOnly From, DateOnly To, ReservationStatus Status);
public record MoneyDto(decimal Value, string Currency);
