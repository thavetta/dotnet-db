-- Run all LAB4 database objects
:r .\01_Create_Function_fn_Nights.sql
:r .\02_Create_SPs_Reservation_CUD.sql
