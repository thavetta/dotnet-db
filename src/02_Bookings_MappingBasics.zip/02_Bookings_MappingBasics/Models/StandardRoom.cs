namespace Bookings.Models;

public class StandardRoom : Room
{
}