using System.Diagnostics;
using Bogus;
using Bookings.Contexts;
using Bookings.Models;
using Microsoft.EntityFrameworkCore;

namespace Bookings.Infrastructure;

public static class SeedingExtensions
{
    public static WebApplication UseSeeding(this WebApplication app)
    {
        app.MapPost("/seed", async (BookingsDbContext db, int guests = 200, int rooms = 50, int reservations = 500) =>
        {
            await db.Database.MigrateAsync();

            if (await db.Guests.AnyAsync() || await db.Rooms.AnyAsync() || await db.Reservations.AnyAsync())
                return Results.Ok(new { ok = true, skipped = true });

            var sw = Stopwatch.StartNew();
            await using var tx = await db.Database.BeginTransactionAsync();

            // Rooms (TPC: StandardRoom/Suite) – Room.Id je int (IDENTITY/SEQUENCE), takže nepředáváme Id, jen business fields.
            var stdRooms = new Faker<StandardRoom>("en")
                .CustomInstantiator(f => new StandardRoom(
                    number: f.Random.Int(100, 499).ToString(),
                    capacity: f.Random.Int(1, 3)
                ))
                .Generate(Math.Max(1, rooms * 3 / 4));

            var suites = new Faker<Suite>("en")
                .CustomInstantiator(f => new Suite(
                    number: f.Random.Int(500, 899).ToString(),
                    capacity: f.Random.Int(2, 6),
                    hasLounge: f.Random.Bool(0.4f)
                ))
                .Generate(max(1, rooms - stdRooms.Count));

            await db.AddRangeAsync(stdRooms);
            await db.AddRangeAsync(suites);
            await db.SaveChangesAsync(); // uložit, aby měly přidělené Id (int)

            // Guests (Guid Id)
            var guestFaker = new Faker<Guest>("en")
                .CustomInstantiator(f => new Guest(
                    id: Guid.NewGuid(),
                    name: f.Name.FullName(),
                    email: Email.Create(f.Internet.Email()),
                    isVip: f.Random.Bool(0.1f)
                ));
            var guestsList = guestFaker.Generate(guests);
            await db.AddRangeAsync(guestsList);

            // Reservations (Guid Id, RoomId:int, GuestId:Guid, DateTime CheckIn/Out, Money Price, Status:string enum)
            var allRooms = stdRooms.Cast<Room>().Concat(suites).ToList();
            var resFaker = new Faker<Reservation>("en")
                .CustomInstantiator(f =>
                {
                    var checkIn = DateTime.UtcNow.Date.AddDays(-f.Random.Int(0, 120)).AddHours(f.Random.Int(14, 20));
                    var nights = f.Random.Int(1, 10);
                    var checkOut = checkIn.AddDays(nights);
                    var room = f.PickRandom(allRooms);
                    // Simplified pricing: 75–180 per night standard, 160–380 per night suite
                    var baseRate = (room is Suite ? f.Random.Decimal(160, 380) : f.Random.Decimal(75, 180));
                    var price = new Money(decimal.Round((decimal)baseRate * nights, 2), "EUR");
                    var status = f.PickRandom<ReservationStatus>();
                    return new Reservation(
                        id: Guid.NewGuid(),
                        roomId: room.Id,
                        guestId: f.PickRandom(guestsList).Id,
                        checkIn: checkIn,
                        checkOut: checkOut,
                        price: price,
                        status: status
                    );
                })
                .Generate(reservations);

            await db.AddRangeAsync(resFaker);

            await db.SaveChangesAsync();
            await tx.CommitAsync();
            sw.Stop();

            return Results.Ok(new { ok = true, inserted = new { guests = guestsList.Count, rooms = allRooms.Count, reservations = resFaker.Count }, ms = sw.ElapsedMilliseconds });
        });

        return app;
    }
}
