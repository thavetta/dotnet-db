namespace Bookings.Models;

public class Suite : Room 
{ 
    public bool HasLounge { get; set; } 
}
