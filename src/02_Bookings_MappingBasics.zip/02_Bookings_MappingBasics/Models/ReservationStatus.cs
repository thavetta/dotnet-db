namespace Bookings.Models;

public enum ReservationStatus 
{ 
    Pending,
    Confirmed,
    Cancelled,
    CheckedIn,
    CheckedOut
}