# 03 – Bookings (Mapping Advanced)

**Cíl:** Ukázat pokročilé mapování v EF Core: **TPC dědičnost (a)**, **backing field (b)**, **globální filtr (c)**, **ValueConverter bool→Y/N (d)**, **ValueComparer (e)**, **konstruktory s parametry (f)**, **keyless entita navázaná na VIEW (g)**, **shadow properties (h)**, **shared-type entity (i)** a **HasData seed vč. FK (j)**.

Každý soubor má níže vlastní oddíl s krátkým popisem a **kompletním kódem**. Na konci je postup pro migraci a vytvoření VIEW.

---

## Models/Email.cs
Value object pro e‑mail. Mapujeme ho přes **ValueConverter** na `string` a přidáváme **ValueComparer** (case‑insensitive), aby EF správně poznal změny jen ve velikosti písmen.
```csharp
// viz soubor v projektu
```

## Models/Money.cs
Value object pro cenu. Uloženo jako **owned typ** v `Reservation` se sloupci `Price_Amount` a `Price_Currency`.
```csharp
// viz soubor v projektu
```

## Models/ReservationStatus.cs
Výčet stavů rezervace. V DB ho ukládáme jako **string** (viz DbContext).
```csharp
// viz soubor v projektu
```

## Models/Room.cs
Abstraktní základ pro pokoje. V tomto labu používáme **TPC** – každý potomek má vlastní tabulku.
```csharp
// viz soubor v projektu
```

## Models/StandardRoom.cs
Konkrétní pokoj. V TPC má **tabulku `StandardRooms`** (viz DbContext) a demonstrační seed.
```csharp
// viz soubor v projektu
```

## Models/Suite.cs
Druhá větev s vlastností `HasLounge`. V TPC má **tabulku `Suites`**.
```csharp
// viz soubor v projektu
```

## Models/Guest.cs
Entita `Guest` demonstruje **backing field** pro `Name`, **globální filtr** `IsDeleted`, **converter bool→Y/N** pro `IsVip`, `RowVersion` pro concurrency a mapování `Email` přes converter + comparer.
```csharp
// viz soubor v projektu
```

## Models/Reservation.cs
Používá **konstruktor s parametry**. Má FK na `Room`/`Guest`, `Price: Money` (owned) a `Status: ReservationStatus` (string).
```csharp
// viz soubor v projektu
```

## Models/ReservationSummary.cs
(g) **Keyless** třída pro **VIEW** `vwReservationSummary`.
```csharp
// viz soubor v projektu
```

## Contexts/BookingsDbContext.cs — hlavička a DbSety
- Nastaví **schema `bookings`** a **TPC** pro `Room` a potomky.
- Deklaruje `DbSet` včetně **keyless** entity pro view a **shared-type** entit pro nastavení.
```csharp
// viz soubor v projektu
```

### Mapování entit — co se nastavuje
- **Guest**: backing field `_name`; index na `Name`; `RowVersion`; globální filtr `!IsDeleted`; `IsVip` přes converter Y/N; `Email` přes converter + comparer; **HasData** (Alice).
- **Room (TPC)**: `UseTpcMappingStrategy()`; `StandardRooms` a `Suites` mají vlastní tabulky; **HasData** (101, 501).
- **Reservation**: `RowVersion`; `Status` jako string; FK na `Room` (Restrict) a `Guest`; **owned `Price`** (Amount/Currency) + **HasData** (včetně owned části); index `(RoomId, CheckIn, CheckOut)`.
- **ReservationSummary**: `ToView("vwReservationSummary")`, `HasNoKey()`.
- **Shared-type entity**: `UserSettings`/`SystemSettings` sdílí tabulku `Settings`, odlišeno sloupcem `Kind` + query filter; `SaveChanges` automaticky doplňuje `Kind`; **HasData**.

## Program.cs — inicializace
- Connection string (LocalDB jako výchozí), registrace DbContextu (SQL Server + retry), v Dev **`Database.Migrate()`**.

## Program.cs — mapování URL
- `GET /health` — kontrola běhu.  
- `POST /seed` — idempotentní nasypání dat.  
- `GET /rooms` — kontrola TPC (seznam StandardRooms/Suites).

---

## Migrace, VIEW a spuštění

1. EF CLI (jednou):
   ```bash
   dotnet tool update --global dotnet-ef
   ```
2. Vytvoř migraci (v adresáři projektu `03_Bookings_MappingAdvanced`):
   ```bash
   dotnet ef migrations add AdvancedMapping_Start -o Contexts/Migrations
   ```
3. Do metody `Up()` doplň SQL pro VIEW (TPC ⇒ `UNION ALL` přes `StandardRooms` a `Suites`):
   ```sql
   CREATE VIEW [bookings].[vwReservationSummary] AS
   SELECT r.Number AS RoomNumber,
          COUNT(res.Id) AS ReservationsCount,
          SUM(res.Price_Amount) AS TotalAmount
   FROM (
       SELECT Id, RoomId, Price_Amount FROM [bookings].[Reservations]
   ) res
   JOIN (
       SELECT Id, Number FROM [bookings].[StandardRooms]
       UNION ALL
       SELECT Id, Number FROM [bookings].[Suites]
   ) r ON r.Id = res.RoomId
   GROUP BY r.Number;
   ```
   (Do migrace vlož `migrationBuilder.Sql(@"...");` a přidej i `DROP VIEW` do `Down()`.)
4. Aplikuj migraci:
   ```bash
   dotnet ef database update
   ```
5. Spusť aplikaci a seed:
   ```bash
   dotnet run
   curl -X POST http://localhost:5000/seed
   ```
6. Ověření (SSMS):
   ```sql
   SELECT * FROM [bookings].[StandardRooms];
   SELECT * FROM [bookings].[Suites];
   SELECT * FROM [bookings].[Reservations];
   SELECT * FROM [bookings].[Settings];
   SELECT * FROM [bookings].[vwReservationSummary];
   ```
