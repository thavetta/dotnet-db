using Bookings.Models;

namespace Bookings.Dtos;

public record ReservationCreateDto(Guid GuestId, int RoomId, DateTime CheckIn, DateTime CheckOut, MoneyDto Price);
public record ReservationUpdateDto(DateTime CheckIn, DateTime CheckOut, ReservationStatus Status);
public record MoneyDto(decimal Amount, string Currency);
