namespace Bookings.Infrastructure;

public static class DbFunctions
{
    public static int Nights(DateTime from, DateTime to) => (int)(to.Date - from.Date).TotalDays;
}
