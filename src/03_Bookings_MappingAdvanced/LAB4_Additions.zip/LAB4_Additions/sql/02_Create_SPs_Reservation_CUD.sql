CREATE OR ALTER PROCEDURE dbo.Reservation_Insert
    @Id uniqueidentifier,
    @GuestId uniqueidentifier,
    @RoomId uniqueidentifier,
    @From date,
    @To date,
    @Status int,
    @Total_Value decimal(18,2),
    @Total_Currency nvarchar(3)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.Reservations(Id, GuestId, RoomId, [From], [To], Status, Total_Value, Total_Currency)
    VALUES (@Id, @GuestId, @RoomId, @From, @To, @Status, @Total_Value, @Total_Currency);
END
GO

CREATE OR ALTER PROCEDURE dbo.Reservation_Update
    @Id uniqueidentifier,
    @From date,
    @To date,
    @Status int
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.Reservations
      SET [From]=@From, [To]=@To, Status=@Status
      WHERE Id=@Id;
END
GO

CREATE OR ALTER PROCEDURE dbo.Reservation_Delete
    @Id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM dbo.Reservations WHERE Id=@Id;
END
GO
